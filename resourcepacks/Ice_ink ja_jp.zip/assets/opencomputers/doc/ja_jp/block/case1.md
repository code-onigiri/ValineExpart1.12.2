# コンピューターケース

![ケースにすっぽり](oredict:oc:case1)

コンピューターケースには3つのTierがあり、ケースに 搭載できるコンポーネントの数が異なります。 クリエイティブモードでのみ使用できる、追加のTierもあります。
コンピューターケースを[アセンブラー](assembler.md)内にいれて、[ロボット](robot.md)に仕立て上げることもできます。

コンピューターケース内に搭載できる各コンポーネントごとの最大Tierは、それぞれのスロットの隅に小さく表示されているローマ数字で確認できます。 また、Tier2のスロットにはTier1のコンポーネントを搭載できます。

-

Tier1のケースには、次のようなコンポーネントを搭載できます。
- 2x tier 1 拡張カード
([グラフィクカード](../item/graphicsCard1.md), [ネットワークカード](../item/lanCard.md), など)
- 1x tier 1 [CPU](../item/cpu1.md)
- 2x tier 1 [RAM](../item/ram1.md)
- 1x tier 1 [HDD](../item/hdd1.md)

Tier2のケースには、次のようなコンポーネントを搭載できます。
- 1x tier 1 拡張カード
([グラフィクカード](../item/graphicsCard1.md), [ネットワークカード](../item/lanCard.md), など)
- 1x tier 2 拡張カード
- 1x tier 2 [CPU](../item/cpu2.md)
- 2x tier 2 [RAM](../item/ram3.md)
- 1x tier 1 [HDD](../item/hdd1.md)
- 1x tier 2 [HDD](../item/hdd2.md)

Tier3のケースには、次のようなコンポーネントを搭載できます。
- 1x tier 3 拡張カード
([グラフィクカード](../item/graphicsCard1.md), [ネットワークカード](../item/lanCard.md), など)
- 2x tier 2 拡張カード
- 1x tier 3 [CPU](../item/cpu3.md)
- 2x tier 3 [RAM](../item/ram5.md)
- 1x tier 2 [HDD](../item/hdd2.md)
- 1x tier 3 [HDD](../item/hdd3.md)
- 1x [フロッピーディスク](../item/floppy.md)

Tier4(クリエイティブ)のケースには、次のようなコンポーネントを搭載できます。
- 3x tier 3 拡張カード
([グラフィクカード](../item/graphicsCard1.md), [ネットワークカード](../item/lanCard.md), など)
- 1x tier 3 [CPU](../item/cpu3.md)
- 2x tier 3 [RAM](../item/ram5.md)
- 2x tier 3 [HDD](../item/hdd3.md)
- 1x [フロッピーディスク](../item/floppy.md)
　
　