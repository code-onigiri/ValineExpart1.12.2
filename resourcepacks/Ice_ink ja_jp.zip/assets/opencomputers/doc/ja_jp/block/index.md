# ブロック

この目次では、OpenComputersのブロックに関する全てのドキュメント(文書)が一覧になっています。
アイテムを探している場合は、[アイテム・目次](../item/index.md)を ご覧ください。

使用するレシピの構成によっては、一部利用できないものがあることに注意してください。

## コンピューター
* [コンピューターケース](case1.md)
* [マイクロコントローラー](microcontroller.md)
* [ラック](rack.md)
* [ロボット](robot.md)

## コンポーネント類

### 入力 / 出力
* [ホログラムプロジェクター](hologram1.md)
* [キーボード](keyboard.md)
* [スクリーン](screen1.md)

### ストレージ
* [ディスクドライブ](diskdrive.md)
* [RAID](raid.md)

### 拡張機能
* [アダプター](adapter.md)
* [ジオライザー](geolyzer.md)
* [モーションセンサー](motionsensor.md)
* [レッドストーン I/O](redstone.md)
* [トランスポーザー](transposer.md)
* [ウェイポイント](waypoint.md)

## 組み立て / 印刷
* [3Dプリント](print.md)
* [3Dプリンター](printer.md)
* [アセンブラー](assembler.md)
* [キャメリウムブロック](chameliumblock.md)
* [ディスアセンブラー](disassembler.md)

## ネットワーキング
* [ケーブル](cable.md)
* [ネットスプリッター](netsplitter.md)
* [リレー](relay.md)

## 電源管理
* [キャパシター](capacitor.md)
* [チャージャー](charger.md)
* [パワーコンバーター](powerconverter.md)
* [パワーディストリビューター](powerdistributor.md)
 
 