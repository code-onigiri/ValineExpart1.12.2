# トランスポーザー

![ああいう気取り屋(Such a poser)](oredict:oc:transposer)

トランスポーザーは、レッドストーンで制御されるホッパーと[ロボット](robot.md)との隔たりを埋め、隣接するブロック間でのアイテムや液体の転送を[コンピューター](../general/computer.md)によって
制御できるようにします。

*このブロック自体には内部インベントリがありません*

物品を移動させるほかに、[インベントリコントローラーアップグレード](../item/inventoryControllerUpgrade.md)を使用でき
る[アダプター](adapter.md)や[タンクコントローラーアップグレード](../item/tankControllerUpgrade.md)が
搭載されたアダプターなど、隣接するインベントリの中身を検査することにも使用できます。
 
 