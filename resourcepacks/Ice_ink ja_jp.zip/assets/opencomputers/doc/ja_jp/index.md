# OpenComputers-マニュアル

OpenComputersは、永続性があり, モジュール化され,
高度な設定が可能な[コンピューター](general/computer.md), [サーバー](item/server1.md), [ロボット](block/robot.md), 
[ドローン](item/drone.md)をゲームに追加するMODです。  

全てのデバイスは Lua5.2 を使用してプログラミングが
可能であり、使用用途に応じて複雑にも簡潔にもなります。  

マニュアルの使用方法については[マニュアル](item/manual.md)のページを
ご覧ください。  
(緑色のテキストはクリックできるリンクになっています)


## 目次

### デバイス類
- [コンピューター](general/computer.md)
- [サーバー](item/server1.md)
- [マイクロコントローラー](block/microcontroller.md)
- [ロボット](block/robot.md)
- [ドローン](item/drone.md)

### ソフトウェアとプログラミング
- [OpenOS](general/openos.md)
- [Lua](general/lua.md)

### ブロック / アイテム
- [アイテム・目次](item/index.md)
- [ブロック・目次](block/index.md)

### ガイド
- [初めに・Getting Started](general/quickstart.md)


## 概要

先に述べられているように、OpenComputersのコンピューターは永続性を備えています。

具体的には実行中の[コンピューター](general/computer.md)はその場のチャンクが読み込まれなくなっても状態を保持します。

つまりプレイヤーが[コンピューター](general/computer.md)から離れる、または ログオフすると[コンピューター](general/computer.md)は自身の最後の 状態を記憶し、プレイヤーが[コンピューター](general/computer.md)に近づく と、その時点から再開します。

こうした永続性(Persistence)は、タブレットを除く全ての装置において機能します。


全てのデバイス(装置)はモジュール形式となっており、 実際の[コンピューター](general/computer.md)と同様に、さまざまなコンポーネント(部品)から組み立てることができます。  

部品いじりの好きなプレイヤーは、デバイスの最適化を心ゆくまで楽しめるでしょう。

初期の構成に満足できない時は、必要に応じてデバイスの分解、[再構築](block/disassembler.md)が行えます。

[コンピューター](general/computer.md)と[サーバー](item/server1.md)の場合、実行中でも対応GUIを開いて部品交換が行えます。


OpenComputersのデバイスは色々なMODとの互換性があり、そうしたブロックやエンティティに対する操作が行えます。([アダプター](block/adapter.md)、または[ロボット](block/robot.md)や[ドローン](item/drone.md)の 特定のアップグレードを介して) 

電力は、RF(Redstone_Flux), EU(Energy Unit), J(Mekanism Joules), AE(Applied Energistics 2), Charge(Factorization Charge)に対応していますが、 これらに限らず、幅広いMODのからの供給が行えます。


[ロボット](block/robot.md)は、[コンピューター](general/computer.md)の操作や、ワールド上へ 干渉することが可能です。
(ただし、外付けにあたるOpenComputersのブロックには干渉できません)

[コンピューター](general/computer.md)とは異なり、構築が済んだ後の[ロボット](block/robot.md)は内部の部品を取り除けません。

こうした制限の回避として、[アップグレード](item/upgradeContainer1.md)や[カード](item/cardContainer1.md)コンテナを使って[ロボット](block/robot.md)を構築しすることで、必要に応じてカードの交換やアップグレードができます。

[ロボット](block/robot.md)に[OpenOS](general/openOS.md)をインストールするには、 コンテナスロットに[ディスクドライブ](block/diskDrive.md)を配置して[フロッピー](item/floppy.md)ディスクを挿入できるようにする、または [ハードドライブ](item/hdd1.md)スロットの1つに、[OpenOS](general/openOS.md)がプリインス トール(事前に導入)された[ハードドライブ](item/hdd1.md)を配置する ことで行えます。

[ロボット](block/robot.md)は分解することで完全な再構築が行えます。 
[ドローン](item/drone.md)は[ロボット](block/robot.md)の限定的な仕様のものです。 移動方法が異なり、インベントリスロットも少なく、 オペレーティングシステムもありません。
([マイクロコントローラー](block/microcontroller.md)と同じく、[ドローン](item/drone.md)は限定的な 作業に向けてプログラムされた[EEPROM](item/eeprom.md)から設定できます) 

ほとんどのアップグレードやコンポーネント(部品)は、[ロボット](block/robot.md)と[ドローン](item/drone.md)で同じものを使用できます。 
ただしアップグレードに関しては、[ドローン](item/drone.md)において 異なる動作をします。

例えば[インベントリアップグレード](item/inventoryUpgrade.md)では、搭載する ごとに4スロット、合計8スロットの追加が行えますが、[ロボット](block/robot.md)の場合は搭載できる数も多く、そのアップグレードで増やせるスロットも多くなっています。
(搭載するごとに16スロット追加)


このマニュアルには、全てのブロックとアイテムに関する詳細情報、様々な種類のシステムとデバイスの環境構築方法、およびLuaプログラミンに関する概要が含まれています。
 
 