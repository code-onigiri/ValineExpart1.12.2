# 抽象化バス

![さらなる接続を！](oredict:oc:abstractBusCard)

このカードを[コンピューター](../general/computer.md), [サーバー](server1.md), [ロボット](../block/robot.md)に搭載することで、StargateTech2の抽象化バス(abstract bus)との やりとりが可能になります。

カードが搭載されるとこれらのブロックは抽象化バスに接続され、抽象化バスを介したメッセージの送信が可能になり、マシンにおいてコンポーネントが使用可能になります。

着信抽象化バス(Incoming abstract bus)は、マシンへ送られ る信号へ変換されます。
 
 