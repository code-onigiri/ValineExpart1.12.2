# 算術ロジックユニット(ALU)

![わたし、気になります！](oredict:oc:materialALU)

[CPU](cpu1.md)や[グラフィックカード](graphicsCard1.md)など、計算を実行するコンポーネントを作成することに使われます。
