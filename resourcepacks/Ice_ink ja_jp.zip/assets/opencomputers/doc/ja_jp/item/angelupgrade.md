# エンジェルアップグレード

![ハレルヤ(Hallelujah).](oredict:oc:angelUpgrade)

このアップグレードにより、[ロボット](../block/robot.md)は参照するブロックなしに空中にブロックを配置することが可能になります。
 
  