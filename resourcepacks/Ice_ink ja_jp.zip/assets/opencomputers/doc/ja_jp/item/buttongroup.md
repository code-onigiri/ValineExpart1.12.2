# ボタングループ

![Needs more buttons.](oredict:oc:materialButtonGroup)

あなたは*常に*、どこかしらにある無数のボタンに囲まれ ています。
嘘はつきません。
私達は皆、ボタンのレシピをShift-クリックで何度も押し ます。

ボタングループは[キーボード](../block/keyboard.md)の組み立てで使用されま す。
 
 