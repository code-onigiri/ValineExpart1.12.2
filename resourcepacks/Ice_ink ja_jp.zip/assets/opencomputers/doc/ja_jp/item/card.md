# カード基盤

![これはまだ読み込めません。](oredict:oc:materialCard)

OpenComputersのカードコンポーネントにおける、普遍的なクラフト素材です。
([グラフィックカード](graphicsCard1.md), [ネットワークカード](lanCard.md)など)
 
  