# カードコンテナ

![Can haz cards!](oredict:oc:cardContainer1)

カードコンテナは[ロボット](../block/robot.md)の格納機能をアップグレー
ドさせるものであり、[ロボット](../block/robot.md)へオンザフライ(実行中)で
搭載、取り外しが行えます。

スロットが保持できるカードの最大Tierは、コンテナのTier数と同じものとなっています。

通常のアップグレードと異なり、コンテナが及ぼす
複雑さ(complexity)は、そのTierの2倍となっています。

ロボットの複雑さ(complexity)については[こちら](../block/robot.md)を参照し
てください。
 
  