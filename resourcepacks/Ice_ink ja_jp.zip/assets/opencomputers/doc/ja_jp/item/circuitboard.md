# 回路基板

![もっと金が欲しい。](oredict:oc:materialCircuitBoard)

[未加工の回路基板](rawCircuitBoard.md)から作成でき、[プリント基板(PCB)](printedCircuitBoard.md)の
作成に使われる中間素材です。
 
  