# コントロールユニット

![クルーズコントロール機能搭載](oredict:oc:materialCU)

[CPU](cpu1.md)などのより高度な回路において使用される高Tierのクラフトアイテムです。
 
  