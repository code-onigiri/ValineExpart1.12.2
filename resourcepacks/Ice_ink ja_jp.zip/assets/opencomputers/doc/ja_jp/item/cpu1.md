# CPU

![Braaainz.](oredict:oc:cpu1)

中央処理装置(central processing unit)は、 それぞれの[コンピューター](../general/computer.md)や[サーバー](server1.md)の中核部分です。

[コンピューター](../general/computer.md)のアーキテクチャ(設計)、 および[コンピューター](../general/computer.md)が動作停止するまでに接続できるコンポーネントの数を決定します。

また、高TierのCPUはより高いTick毎の直接呼び出しの制限を[コンピューター](../general/computer.md)に提供します。

- 簡単に言うと: 良いCPUは動作が早い

各CPUが許容するコンポーネント数は、次のとおりです。
- Tier 1: 8 のコンポーネント
- Tier 2: 12 のコンポーネント
- Tier 3: 16 のコンポーネント

[サーバー](server1.md)では、[コンポーネントバス](componentBus1.md)を導入することで コンポーネントの許容数をさらに増加させることができます。

[コンピューター](../general/computer.md)に許容量を超える数のコンポーネントが接続されている場合は起動ができなくなり、起動している場合はクラッシュが起こります。
 
  