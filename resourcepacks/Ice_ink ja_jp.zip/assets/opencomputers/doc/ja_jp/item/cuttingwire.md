# カッティングワイヤー

![ギャロット(鉄環絞首刑)じゃありません。まったくもって。](oredict:oc:materialCuttingWire)

[未加工の回路基板](rawCircuitBoard.md)の作成に使われる、ハードモードレシ　ピにおいてのみ現れるアイテムです。  非常に非効率的です。
 
  