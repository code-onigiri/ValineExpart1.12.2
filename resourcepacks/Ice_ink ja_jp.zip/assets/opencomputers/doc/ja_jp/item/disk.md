# ディスク

![RIP テリー・プラチェット(Discworld:1983年)](oredict:oc:materialDisk)

[フロッピー](floppy.md)や[ハードディスク](hdd1.md)などの、ストレージメディアの作成時に使用される、基本的なクラフトコンポーネントです。
 
  