# マウンタブル-ディスクドライブ

![中にぴったり](oredict:oc:diskDriveMountable)

通常の[ディスクドライブ](../block/diskDrive.md)と同じ機能をもつデバイスで
すが、[ラック](../block/rack.md)に搭載できるようになっています。
 
  