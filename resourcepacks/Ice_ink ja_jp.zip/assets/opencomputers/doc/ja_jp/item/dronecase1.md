# ドローンケース

![ドローイング、オン](oredict:oc:droneCase1)

ドローンケースは、[アセンブラー](../block/assembler.md)で[ドローン](drone.md)を組み立て る際に使用されます。

[ドローン](drone.md)は機能が制限された、軽量かつ高速な、非常に使い勝手の良いマシンです。
(アップグレードとコンポーネントのスロットが少なくなっています) 

[ロボット](../block/robot.md)とは異なり、これらはツール類を使用できず、 ワールド上への干渉も比較的限られたものとなっています。

-

速度と稼働時のエネルギーコストの低さが、これらの制限を補っています。

ごく少量のアイテムの輸送に適しており、偵察にも最適です。

[ドローン](drone.md)と[ロボット](../block/robot.md)の組み合わせは非常に強力です。

例えば、[ロボット](../block/robot.md)は"ハード面での役割"を担い、[ドローン](drone.md)は周辺環境に関する情報を収集し、中央ハブからのアイテムのやり取りを担います。

-

[マイクロコントローラー](../block/microcontroller.md)と同様に、[ドローン](drone.md)は[EEPROM](eeprom.md)を 使ってのみプログラミングが行えます。

そうしたことに伴い、[ドローン](drone.md)を別の[EEPROM](eeprom.md)と共にクラ フトすることで、[EEPROM](eeprom.md)の交換が行えるようになってい ます。

既に搭載されていた[EEPROM](eeprom.md)はプレイヤーのインベント リへ戻ります。

-

Tier1のドローンケースでは、次のようなコンポーネントを使用できます。
- 1x tier 1 [CPU](cpu1.md)
- 1x tier 1 [RAM](ram1.md)
- 1x [EEPROM](eeprom.md)
- 1x 拡張カード (tier 2)
- 1x 拡張カード (tier 1)
- 1x アップグレード (tier 1)
- 1x アップグレード (tier 2)

-

Tier2のドローンケースでは、次のようなコンポーネントを使用できます。
- 1x tier 1 [CPU)](cpu1.md)
- 2x tier 1 [RAM](ram1.md)
- 1x [EEPROM](eeprom.md)
- 2x 拡張カード (tier 2)
- 1x アップグレード (tier 1)
- 1x アップグレード (tier 2)
- 1x アップグレード (tier 3)

-

Tier4(クリエイティブ)のドローンケースでは、次のようなコンポーネントを使用できます。
- 1x tier 3 [CPU](cpu3.md)
- 2x tier 3 [RAM](ram5.md)
- 1x [EEPROM](eeprom.md)
- 3x 拡張カード (tier 3)
- 9x アップグレード (tier 3)
 
  