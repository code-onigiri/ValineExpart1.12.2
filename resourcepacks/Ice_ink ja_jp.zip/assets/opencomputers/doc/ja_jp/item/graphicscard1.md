# グラフィックカード

![派手な画像](oredict:oc:graphicsCard1)

グラフィックカードはほとんどの[コンピューター](../general/computer.md)に
必要となる部品であり、[コンピューター](../general/computer.md)に接続させた
[スクリーン](../block/screen1.md)(画面)にテキストを表示できるようになり ます。

このカードにはいくつかのTierがあり、[スクリーン](../block/screen1.md)と
同じく様々な解像度や色深度に対応しています。

-

また、これらのTierにおけるもう一つの差異は、グラ
フィックカードがTick毎に実行できる操作の数です。

グラフィックカードのツールチップにリストされている
値には、Tier2 [CPU](cpu1.md)を搭載した[コンピューター](../general/computer.md)の値が使わ れています。

Tier1 CPUのパフォーマンスは"ほんのりと"遅く、
Tier3 CPUでは"心もち"速くなっています。

リストされている数値はGPUが提供する様々な操作、
つまり`copy`, `fill`, `set`, `setBackground`,
および`setForeground`,におけるものです。
 
 