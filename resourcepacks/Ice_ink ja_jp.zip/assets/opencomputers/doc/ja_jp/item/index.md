# アイテム

この目次では、OpenComputersのアイテムに関する全てのドキュメント(文書)が一覧になっています。 
ブロックを探している場合は、[ブロック・目次](../block/index.md)を ご覧ください。

使用するレシピの構成によっては、一部利用できないものがあることに注意してください。

## ツール類
* [アナライザー](analyzer.md)
* [マニュアル](manual.md)
* [リモートターミナル](terminal.md)
* [テクスチャピッカー](texturepicker.md)
* [スクレンチ](wrench.md)

## デバイス類
* [ドローン](drone.md)
* [サーバー](server1.md)
* [タブレット](tablet.md)

## コンポーネント類

### 拡張カード
* [抽象化バスカード](abstractbuscard.md)
* [データカード](datacard1.md)
* [デバッグカード](debugCard.md) (aka ami)
* [グラフィックカード](graphicscard1.md)
* [インターネットカード](internetcard.md)
* [リンク済みカード](linkedcard.md)
* [ネットワークカード](lancard.md)
* [レッドストーンカード](redstonecard1.md)
* [無線ネットワークカード](wlanCard1.md)
* [ワールドセンサーカード](worldsensorcard.md)

### アップグレード
* [エンジェルアップグレード](angelupgrade.md)
* [バッテリーアップグレード](batteryupgrade1.md)
* [カードコンテナ](cardcontainer1.md)
* [チャンクロードアップグレード](chunkloaderupgrade.md)
* [クラフティングアップグレード](craftingupgrade.md)
* [データベースアップグレード](databaseupgrade1.md)
* [経験値アップグレード](experienceupgrade.md)
* [発電アップグレード](generatorupgrade.md)
* [ホバーアップグレード](hoverupgrade1.md)
* [インベントリコントローラー](inventorycontrollerupgrade.md)
* [インベントリアップグレード](inventoryupgrade.md)
* [リードアップグレード](leashupgrade.md)
* [MFU](mfu.md)
* [ナビゲーションアップグレード](navigationupgrade.md)
* [ピストンアップグレード](pistonupgrade.md)
* [サインアップグレード](signupgrade.md)
* [ソーラー発電アップグレード](solargeneratorupgrade.md)
* [タンクコントローラー](tankcontrollerupgrade.md)
* [タンクアップグレード](tankupgrade.md)
* [トラクタービームアップグレード](tractorbeamupgrade.md)
* [トレーディングアップグレード](tradingupgrade.md)
* [アップグレードコンテナ](upgradecontainer1.md)

### ラックに搭載可能
* [ディスクドライブ](diskdrivemountable.md)
* [サーバー](server1.md)
* [ターミナルサーバー](terminalserver.md)

### その他
* [APU](apu1.md)
* [コンポーネントバス](componentbus1.md)
* [CPU](cpu1.md)
* [EEPROM](eeprom.md)
* [フロッピー](floppy.md)
* [ハードディスクドライブ](hdd1.md)
* [メモリー (RAM)](ram1.md)

## クラフト素材
* [腐食液](acid.md)
* [ALU](alu.md)
* [矢印キー](arrowkeys.md)
* [ボタングループ](buttongroup.md)
* [カード基材](card.md)
* [回路基板](circuitboard.md)
* [コントロールユニット](controlunit.md)
* [カッティングワイヤー](cuttingwire.md)
* [ディスク](disk.md)
* [インタウェブ](interweb.md)
* [マイクロチップ](chip1.md)
* [テンキーパッド](numpad.md)
* [プリント基板 (PCB)](printedcircuitboard.md)
* [未加工の回路基板](rawcircuitboard.md)
* [トランジスタ](transistor.md)

## 組み立て / 印刷
* [キャメリウム](chamelium.md)
* [インクカートリッジ](inkcartridge.md)
* [ドローン・ケース](dronecase1.md)
* [マイクロコントローラー・ケース](microcontrollercase1.md)
* [タブレット・ケース](tabletcase1.md)

## その他
* [ホバーブーツ](hoverboots.md)
* [ナノマシン](nanomachines.md)
 
  