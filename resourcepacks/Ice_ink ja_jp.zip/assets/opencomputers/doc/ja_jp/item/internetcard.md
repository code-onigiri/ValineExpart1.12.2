# インターネットカード

![映像カットから、3, 2, ...](oredict:oc:internetCard)

インターネットカードは、[コンピューター](../general/computer.md)による インターネットへのアクセスを可能にさせます。

単純なHTTPリクエストを実行する方法、および読み取り/書き込み可能でプレーンなTCPクライアントソケットの開放手段を提供します。
(HTTP: Hypertext Transfer Protocol/ ハイパーテキストトランスファープロトコル)
(TCP: Transmission Control Protocol/ 伝送制御プロトコル) 

[コンピューター](../general/computer.md)にインターネットカードを導入すると、
pastebinからスニペットをダウンロード、およびアップ
ロードを行うためのアプリケーションや、任意のHTTP URLからデータをダウンロードできる`wget`クローンなど、
インターネット関連のいくつかのアプリを含んだカスタムファイルシステムにも接続されます。
 
 