# マイクロコントローラーケース

![なんてかわいらしい。](oredict:oc:microcontrollerCase1)

マイクロコントローラーケースは、[アセンブラー](../block/assembler.md)で[マイクロコントローラー](../block/microcontroller.md)を組み立てる際に使用されま す。

[マイクロコントローラー](../block/microcontroller.md)は非常に原始的な[コンピューター](../general/computer.md)です。

搭載できるコンポーネントの数は非常に限られており、レッドストーン信号の変換や応答、ネットワークメッセージの処理など、非常に特殊な用途において使われることを目的としています。

-

実際のファイルシステムはありません。
全てのプログラミングは、内部の[EEPROM](eeprom.md)チップを使って 実行しなければなりません。

[マイクロコントローラー](../block/microcontroller.md)を別の[EEPROM](eeprom.md)と共にクラフトす ることで、[EEPROM](eeprom.md)の交換が行えるようになっています。

既に搭載されていた[EEPROM](eeprom.md)は、プレイヤーのインベント リへ戻ります。

また、動作には電力が必要になりますが、消費量はごく僅かなものとなっています。

-

Tier1のマイクロコントローラーケースでは、次のようなコンポーネントを使用できます。
- 1x tier 1 [CPU](cpu1.md)
- 1x tier 1 [RAM](ram1.md)
- 1x [EEPROM](eeprom.md)
- 2x 拡張カード (tier 1)
- 1x アップグレード (tier 2)

-

Tier2のマイクロコントローラーケースでは、次のようなコンポーネントを使用できます。
- 1x tier 1 [CPU](cpu1.md)
- 2x tier 1 [RAM](ram1.md)
- 1x [EEPROM](eeprom.md)
- 1x 拡張カード (tier 2)
- 1x 拡張カード (tier 1)
- 1x アップグレード (tier 3)

-

Tier4(クリエイティブ)のマイクロコントローラーケースでは、次のようなコンポーネントを使用できます。
- 1x tier 3 [CPU](cpu3.md)
- 2x tier 3 [RAM](ram5.md)
- 1x [EEPROM](eeprom.md)
- 3x 拡張カード (tier 3)
- 9x アップグレード (tier 3)
 
  