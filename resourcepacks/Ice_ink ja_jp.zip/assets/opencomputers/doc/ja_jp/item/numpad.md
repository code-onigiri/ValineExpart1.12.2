# 数字キーパッド (テンキー)

![指紋を確かめてください。](oredict:oc:materialNumPad)

数字キーパッド(テンキー)は、全ての[キーボード](../block/keyboard.md)の一部 です。 数字を入力できます。
 
  