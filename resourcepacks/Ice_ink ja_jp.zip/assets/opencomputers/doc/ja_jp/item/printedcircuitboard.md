# プリント基板 (PCB)

![AKA PCB](oredict:oc:materialCircuitBoardPrinted)

プリント基板(Printed Circuit Board)は、OpenComputersに おいて、[トランジスター](transistor.md)に次いで基本となるクラフト 素材の1つです。 

[カード基材](card.md)や[ブロック](../block/index.md)など、多数のコンポーネントの 基礎部品として使用されます。
 
  