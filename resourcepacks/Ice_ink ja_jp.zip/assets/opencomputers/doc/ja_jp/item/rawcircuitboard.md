# 未加工の回路基板

![Not sushi.](oredict:oc:materialCircuitBoardRaw)

[回路基板](circuitBoard.md) (使用するレシピ構成によっては[プリント基板](printedCircuitBoard.md) )を作成するときに使用される中間素材です。
 
  