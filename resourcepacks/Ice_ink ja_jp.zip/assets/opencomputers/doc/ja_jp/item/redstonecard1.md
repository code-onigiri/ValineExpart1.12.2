# レッドストーンカード

![赤色のようだ](oredict:oc:redstoneCard1)

レッドストーンカードを使用すると、[コンピューター](../general/computer.md)は隣接するブロックのレッドストーン信号と、その強度の読み取り/発信が行えます。

受信した信号の強度が変化する際も、[コンピューター](../general/computer.md)は 信号の認識を行います。

-

RedLogic, Project Red, MineFactory Reloadedなど、
バンドルされたレッドストーン機能を提供する対応MODが
ある場合、またはWR-CBEやSlimevoid's Wireless modなどの
ワイヤレスなレッドストーン機能を提供するMODのシステ
ムとは、Tier2のカードを使用することでそのやりとりが可能になります。

-

いくつかのメソッドにおいて提供される"side"(側面、
各面)は、[コンピューターケース](../block/case1.md), [ロボット](../block/robot.md), [ラック](../block/rack.md)の
向きに関連しています。

つまり、コンピューターの前面に視点を合わせた場合、
"sides.right"は左側にあり、その逆も然りです。
 
  