# タブレットケース

![折れ曲がったりしない](oredict:oc:tabletCase1)

タブレットケースは、[アセンブラー](../block/assembler.md)で[タブレット](tablet.md)を 組み立てる際に使用されます。

[タブレット](tablet.md)は非常にコンパクトで、携帯性に優れた[コンピューター](../general/computer.md)です。

これらにはアップグレードのうちの一部を搭載できますが、[コンピューターケース](../block/case1.md)のようにワールド上のものに干渉することはできません。
(単純な[ネットワークカード](lanCard.md)、
または[レッドストーンカード](redstoneCard1.md))

-

[タブレット](tablet.md)において使用できないアップグレードや カードは、[アセンブラー](../block/assembler.md)に配置することができません。

アップグレードを[アセンブラー](../block/assembler.md)に搭載できる場合、コンポーネントAPIを介して使用可能です。

実行を継続させるには、プレイヤーのインベントリ内に残しておく必要があります。

ドロップ、または別のインベントリに配置されてしばらくすると、オフ状態になります。

-

Tier1のタブレットケースでは、次のようなコンポーネントを使用できます。
- 1x [CPU (tier 2)](cpu2.md)
- 2x [RAM (tier 2)](ram3.md)
- 1x [HDD (tier 2)](hdd2.md)
- 2x 拡張カード (tier 2)
- 1x [EEPROM](eeprom.md)
- 1x アップグレード (tier 1)
- 1x アップグレード (tier 2)
- 1x アップグレード (tier 3)

-

Tier2のタブレットケースでは、次のようなコンポーネントを使用できます。
- 1x [CPU (tier 3)](cpu3.md)
- 2x [RAM (tier 2)](ram3.md)
- 1x [HDD (tier 2)](hdd2.md)
- 1x 拡張カード (tier 2)
- 1x 拡張カード (tier 3)
- 1x [EEPROM](eeprom.md)
- 2x アップグレード (tier 2)
- 1x アップグレード (tier 3)
- 1x [アップグレード](upgradeContainer2.md) または[カードのコンテナ](cardContainer2.md) (tier 2)

-

Tier4(クリエイティブ)のタブレットケースでは、次のようなコンポーネントを使用できます。
- 1x [CPU (tier 3)](cpu3.md)
- 2x [RAM (tier 3)](ram5.md)
- 1x [HDD (tier 3)](hdd3.md)
- 3x 拡張カード (tier 3)
- 1x [EEPROM](eeprom.md)
- 9x アップグレード (tier 3)
- 1x [アップグレード](upgradeContainer3.md) または[カードのコンテナ](cardContainer3.md) (tier 3)
 
  