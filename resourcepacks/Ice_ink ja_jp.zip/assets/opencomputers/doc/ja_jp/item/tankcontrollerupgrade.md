# タンクコントローラー

![液体のルーティング](oredict:oc:tankControllerUpgrade)

[インベントリコントローラーアップグレード](inventoryControllerUpgrade.md)が通常の インベントリに対する一方、タンクコントローラーの アップグレードは液体タンクへ対応しています。

これによりデバイスは、内部や隣接しているタンクに関するより詳細な情報を参照することが可能になります。
-

このアップグレードは[アダプター](../block/adapter.md)にも搭載できます。

[アダプター](../block/adapter.md)に接続されている[コンピューター](../general/computer.md)が、 [アダプター](../block/adapter.md)に隣接するタンクに関する情報を参照でき ます。

参考: [トランスポーザー](../block/transposer.md)
 
 