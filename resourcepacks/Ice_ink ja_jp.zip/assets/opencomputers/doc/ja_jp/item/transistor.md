# トランジスター

![私は自身の参照を、全て使い果たしたようだ。](oredict:oc:materialTransistor)

トランジスターは、OpenComputersの最も基本的なクラフト素材の1つです。 

主に[マイクロチップ](chip1.md)やその他の電子部品の作成に使用 されます。
 
  