# Minecraft MOD Japanise for MC1.12.2
1.12.2向けの各MODの公式日本語訳や英語表記をベースに改良や翻訳漏れの修正などを行ったリソースパックです。
## 対応MOD
- [Applied Energistics 2](https://www.curseforge.com/minecraft/mc-mods/applied-energistics-2/)
- [Buildcraft](https://www.curseforge.com/minecraft/mc-mods/buildcraft/)
- [Chocolate Quest Repoured](https://www.curseforge.com/minecraft/mc-mods/cqrepoured/)
- [CoFH World](https://www.curseforge.com/minecraft/mc-mods/cofh-world/)
- [Crafting Tweaks](https://www.curseforge.com/minecraft/mc-mods/crafting-tweaks/)
- [Fantastic Lib](https://www.curseforge.com/minecraft/mc-mods/fantastic-lib/)
- [Hwyla](https://www.curseforge.com/minecraft/mc-mods/hwyla/)
- [Industrialcraft² experimental](https://www.curseforge.com/minecraft/mc-mods/industrial-craft/)
- [Open Terrain Generator (OTG)](https://www.curseforge.com/minecraft/mc-mods/open-terrain-generator/)
- [Waila Harvestability](https://www.curseforge.com/minecraft/mc-mods/waila-harvestability/)
- [Wawla - What Are We Looking At](https://www.curseforge.com/minecraft/mc-mods/wawla/)
## ライセンス
This project is licensed under [GNU Free Document License, Version 1.3](https://www.gnu.org/licenses/fdl-1.3.html).
## 制作者
Sora Tonami &lt;[ms0503@outlook.com](mailto:ms0503@outlook.com)&gt; ([@ms0503](https://github.com/ms0503/))
